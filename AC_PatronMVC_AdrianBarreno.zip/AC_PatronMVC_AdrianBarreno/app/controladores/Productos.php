<?php
class Productos {
    private Producto $productoModelo;

    public function __construct() {
        require_once __DIR__ . '/../modelos/Producto.php';
        $this->productoModelo = new Producto();
    }

    public function listar($codCat) {
        $codCat = (int)($codCat ?? 0);

        $productos = $this->productoModelo->getByCategoria($codCat);

        $datos = [
            'titulo' => 'Productos de la Categoría ' . $codCat,
            'productos' => $productos
        ];

        require_once __DIR__ . '/../vistas/paginas/ProductoView.php';
    }
}
