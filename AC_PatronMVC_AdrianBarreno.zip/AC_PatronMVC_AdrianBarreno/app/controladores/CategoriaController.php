<?php
class CategoriaController {

    public function index() {

        require_once __DIR__ . '/../modelos/Categoria.php';

        $catModel = new Categoria();
        $todasLasCategorias = $catModel->listar();

        $datos = [
            'categorias' => $todasLasCategorias
        ];

        require_once __DIR__ . '/../vistas/paginas/CategoriaView.php';
    }
}