<?php

class AuthController
{
    public function loginForm(?string $error = null): void
    {
        $datos = [
            'titulo' => 'Login',
            'error' => $error,
        ];

        require_once __DIR__ . '/../vistas/paginas/LoginView.php';
    }

    public function loginSubmit(): void
    {
        $usuario = trim((string)($_POST['usuario'] ?? ''));
        $clave   = (string)($_POST['clave'] ?? '');

        $credencialesOk =
            $usuario === '<USUARIO_DEMO>' &&
            $clave === '<CLAVE_DEMO>';

        if (!$credencialesOk) {
            $this->loginForm('Usuario o contraseña incorrectos');
            return;
        }

        $_SESSION['auth'] = true;
        $_SESSION['usuario'] = $usuario;

        header('Location: index.php');
        exit;
    }

    public function logout(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                (bool)$params['secure'],
                (bool)$params['httponly']
            );
        }

        session_destroy();

        header('Location: index.php?url=login');
        exit;
    }
}
