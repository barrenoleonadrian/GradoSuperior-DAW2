<?php
class Producto {
    private PDO $db;

    public function __construct() {
        $this->db = new PDO(
            "mysql:host=localhost;dbname=gestorrestaurante;charset=utf8mb4",
            "root",
            "mysql",
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
    }

    public function getByCategoria(int $categoriaId): array {
        $sql = "SELECT * FROM productos WHERE Categoria = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id', $categoriaId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}