<!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
</head>
<body>

<h1><?= htmlspecialchars($datos['titulo'] ?? 'PRODUCTOS', ENT_QUOTES, 'UTF-8') ?></h1>

<?php if (empty($datos['productos'])): ?>
    <p>No hay productos para esta categoría.</p>
<?php else: ?>
    <ul>
        <?php foreach ($datos['productos'] as $p): ?>
            <li>
                <?= htmlspecialchars($p['Nombre'] ?? ($p['nombre'] ?? 'Producto'), ENT_QUOTES, 'UTF-8') ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<p><a href="index.php">Volver a categorías</a></p>

</body>
</html>