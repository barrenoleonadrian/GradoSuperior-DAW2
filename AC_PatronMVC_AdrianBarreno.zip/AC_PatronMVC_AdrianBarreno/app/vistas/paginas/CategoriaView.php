<!DOCTYPE html>
<html>
<head>
    <title>CATEGORIAS</title>
</head>
<body>
<h1>CATEGORIAS</h1>

<ul>
    <?php foreach (($datos['categorias'] ?? []) as $cat): ?>
        <li>
            <a href="index.php?url=productos&codCat=<?= (int)($cat['CodCat'] ?? 0); ?>">
                <?= htmlspecialchars($cat['Nombre'] ?? '', ENT_QUOTES, 'UTF-8') ?>
            </a>
        </li>
    <?php endforeach; ?>
</ul>

</body>
</html>