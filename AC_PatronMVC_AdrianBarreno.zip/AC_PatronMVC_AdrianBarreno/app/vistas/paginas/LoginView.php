<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($datos['titulo'] ?? 'Login', ENT_QUOTES, 'UTF-8') ?></title>
</head>
<body>

<h1>Login</h1>

<?php if (!empty($datos['error'])): ?>
    <p style="color:red;">
        <?= htmlspecialchars($datos['error'], ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<form method="post" action="index.php?url=login_submit">
    <label>
        Usuario:
        <input type="text" name="usuario" required>
    </label>
    <br><br>
    <label>
        Clave:
        <input type="password" name="clave" required>
    </label>
    <br><br>
    <button type="submit">Entrar</button>
</form>

</body>
</html>