<?php
$url = isset($_GET['url']) ? $_GET['url'] : 'inicio';

if ($url == 'productos') {
    require_once '../app/controladores/Productos.php';
    $controlador = new Productos();

    $codCat = isset($_GET['codCat']) ? $_GET['codCat'] : null;
    $controlador->listar($codCat);
} else {
    require_once '../app/controladores/CategoriaController.php';

    $controlador = new CategoriaController();
    $controlador->index();
}
